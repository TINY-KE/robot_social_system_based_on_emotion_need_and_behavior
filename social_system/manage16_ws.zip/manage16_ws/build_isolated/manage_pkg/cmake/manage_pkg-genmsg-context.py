# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/kod/manage16_ws/src/manage_pkg/msg/Arms.msg;/home/kod/manage16_ws/src/manage_pkg/msg/Emotion.msg;/home/kod/manage16_ws/src/manage_pkg/msg/Gaze.msg;/home/kod/manage16_ws/src/manage_pkg/msg/Legs.msg;/home/kod/manage16_ws/src/manage_pkg/msg/Speech.msg;/home/kod/manage16_ws/src/manage_pkg/msg/bhvPara.msg;/home/kod/manage16_ws/src/manage_pkg/msg/bhvGet.msg;/home/kod/manage16_ws/src/manage_pkg/msg/bhvIssue.msg;/home/kod/manage16_ws/src/manage_pkg/msg/bhvReply.msg;/home/kod/manage16_ws/src/manage_pkg/msg/NeedList.msg"
services_str = ""
pkg_name = "manage_pkg"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "manage_pkg;/home/kod/manage16_ws/src/manage_pkg/msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
