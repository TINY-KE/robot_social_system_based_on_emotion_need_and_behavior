// Auto-generated. Do not edit!

// (in-package manage_pkg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Arms {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.call = null;
      this.weight = null;
      this.action = null;
      this.rate = null;
      this.startTime = null;
      this.endTime = null;
    }
    else {
      if (initObj.hasOwnProperty('call')) {
        this.call = initObj.call
      }
      else {
        this.call = false;
      }
      if (initObj.hasOwnProperty('weight')) {
        this.weight = initObj.weight
      }
      else {
        this.weight = 0;
      }
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = '';
      }
      if (initObj.hasOwnProperty('rate')) {
        this.rate = initObj.rate
      }
      else {
        this.rate = 0;
      }
      if (initObj.hasOwnProperty('startTime')) {
        this.startTime = initObj.startTime
      }
      else {
        this.startTime = 0;
      }
      if (initObj.hasOwnProperty('endTime')) {
        this.endTime = initObj.endTime
      }
      else {
        this.endTime = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Arms
    // Serialize message field [call]
    bufferOffset = _serializer.bool(obj.call, buffer, bufferOffset);
    // Serialize message field [weight]
    bufferOffset = _serializer.int8(obj.weight, buffer, bufferOffset);
    // Serialize message field [action]
    bufferOffset = _serializer.string(obj.action, buffer, bufferOffset);
    // Serialize message field [rate]
    bufferOffset = _serializer.int8(obj.rate, buffer, bufferOffset);
    // Serialize message field [startTime]
    bufferOffset = _serializer.int8(obj.startTime, buffer, bufferOffset);
    // Serialize message field [endTime]
    bufferOffset = _serializer.int8(obj.endTime, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Arms
    let len;
    let data = new Arms(null);
    // Deserialize message field [call]
    data.call = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [weight]
    data.weight = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [action]
    data.action = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [rate]
    data.rate = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [startTime]
    data.startTime = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [endTime]
    data.endTime = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.action.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'manage_pkg/Arms';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2e96b405ecb21f8c7398f8670a7903c2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool call
    int8 weight
    string action
    int8 rate
    int8 startTime
    int8 endTime
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Arms(null);
    if (msg.call !== undefined) {
      resolved.call = msg.call;
    }
    else {
      resolved.call = false
    }

    if (msg.weight !== undefined) {
      resolved.weight = msg.weight;
    }
    else {
      resolved.weight = 0
    }

    if (msg.action !== undefined) {
      resolved.action = msg.action;
    }
    else {
      resolved.action = ''
    }

    if (msg.rate !== undefined) {
      resolved.rate = msg.rate;
    }
    else {
      resolved.rate = 0
    }

    if (msg.startTime !== undefined) {
      resolved.startTime = msg.startTime;
    }
    else {
      resolved.startTime = 0
    }

    if (msg.endTime !== undefined) {
      resolved.endTime = msg.endTime;
    }
    else {
      resolved.endTime = 0
    }

    return resolved;
    }
};

module.exports = Arms;
