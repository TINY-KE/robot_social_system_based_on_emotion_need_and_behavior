
"use strict";

let Emotion = require('./Emotion.js');
let NeedList = require('./NeedList.js');
let Gaze = require('./Gaze.js');
let Arms = require('./Arms.js');
let bhvGet = require('./bhvGet.js');
let bhvIssue = require('./bhvIssue.js');
let bhvReply = require('./bhvReply.js');
let Speech = require('./Speech.js');
let Legs = require('./Legs.js');
let bhvPara = require('./bhvPara.js');

module.exports = {
  Emotion: Emotion,
  NeedList: NeedList,
  Gaze: Gaze,
  Arms: Arms,
  bhvGet: bhvGet,
  bhvIssue: bhvIssue,
  bhvReply: bhvReply,
  Speech: Speech,
  Legs: Legs,
  bhvPara: bhvPara,
};
