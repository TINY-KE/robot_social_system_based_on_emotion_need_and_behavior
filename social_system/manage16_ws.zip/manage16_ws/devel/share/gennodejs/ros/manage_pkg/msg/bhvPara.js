// Auto-generated. Do not edit!

// (in-package manage_pkg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Gaze = require('./Gaze.js');
let Emotion = require('./Emotion.js');
let Arms = require('./Arms.js');
let Speech = require('./Speech.js');
let Legs = require('./Legs.js');

//-----------------------------------------------------------

class bhvPara {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.num = null;
      this.time = null;
      this.Needs = null;
      this.CurOrder = null;
      this.TotalOrder = null;
      this.weight = null;
      this.TotalTime = null;
      this.gaze = null;
      this.emotion = null;
      this.arms = null;
      this.speech = null;
      this.legs = null;
    }
    else {
      if (initObj.hasOwnProperty('num')) {
        this.num = initObj.num
      }
      else {
        this.num = 0;
      }
      if (initObj.hasOwnProperty('time')) {
        this.time = initObj.time
      }
      else {
        this.time = 0;
      }
      if (initObj.hasOwnProperty('Needs')) {
        this.Needs = initObj.Needs
      }
      else {
        this.Needs = '';
      }
      if (initObj.hasOwnProperty('CurOrder')) {
        this.CurOrder = initObj.CurOrder
      }
      else {
        this.CurOrder = 0;
      }
      if (initObj.hasOwnProperty('TotalOrder')) {
        this.TotalOrder = initObj.TotalOrder
      }
      else {
        this.TotalOrder = 0;
      }
      if (initObj.hasOwnProperty('weight')) {
        this.weight = initObj.weight
      }
      else {
        this.weight = 0.0;
      }
      if (initObj.hasOwnProperty('TotalTime')) {
        this.TotalTime = initObj.TotalTime
      }
      else {
        this.TotalTime = 0;
      }
      if (initObj.hasOwnProperty('gaze')) {
        this.gaze = initObj.gaze
      }
      else {
        this.gaze = new Gaze();
      }
      if (initObj.hasOwnProperty('emotion')) {
        this.emotion = initObj.emotion
      }
      else {
        this.emotion = new Emotion();
      }
      if (initObj.hasOwnProperty('arms')) {
        this.arms = initObj.arms
      }
      else {
        this.arms = new Arms();
      }
      if (initObj.hasOwnProperty('speech')) {
        this.speech = initObj.speech
      }
      else {
        this.speech = new Speech();
      }
      if (initObj.hasOwnProperty('legs')) {
        this.legs = initObj.legs
      }
      else {
        this.legs = new Legs();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type bhvPara
    // Serialize message field [num]
    bufferOffset = _serializer.int16(obj.num, buffer, bufferOffset);
    // Serialize message field [time]
    bufferOffset = _serializer.int64(obj.time, buffer, bufferOffset);
    // Serialize message field [Needs]
    bufferOffset = _serializer.string(obj.Needs, buffer, bufferOffset);
    // Serialize message field [CurOrder]
    bufferOffset = _serializer.int8(obj.CurOrder, buffer, bufferOffset);
    // Serialize message field [TotalOrder]
    bufferOffset = _serializer.int8(obj.TotalOrder, buffer, bufferOffset);
    // Serialize message field [weight]
    bufferOffset = _serializer.float64(obj.weight, buffer, bufferOffset);
    // Serialize message field [TotalTime]
    bufferOffset = _serializer.int8(obj.TotalTime, buffer, bufferOffset);
    // Serialize message field [gaze]
    bufferOffset = Gaze.serialize(obj.gaze, buffer, bufferOffset);
    // Serialize message field [emotion]
    bufferOffset = Emotion.serialize(obj.emotion, buffer, bufferOffset);
    // Serialize message field [arms]
    bufferOffset = Arms.serialize(obj.arms, buffer, bufferOffset);
    // Serialize message field [speech]
    bufferOffset = Speech.serialize(obj.speech, buffer, bufferOffset);
    // Serialize message field [legs]
    bufferOffset = Legs.serialize(obj.legs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type bhvPara
    let len;
    let data = new bhvPara(null);
    // Deserialize message field [num]
    data.num = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [time]
    data.time = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [Needs]
    data.Needs = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [CurOrder]
    data.CurOrder = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [TotalOrder]
    data.TotalOrder = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [weight]
    data.weight = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [TotalTime]
    data.TotalTime = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [gaze]
    data.gaze = Gaze.deserialize(buffer, bufferOffset);
    // Deserialize message field [emotion]
    data.emotion = Emotion.deserialize(buffer, bufferOffset);
    // Deserialize message field [arms]
    data.arms = Arms.deserialize(buffer, bufferOffset);
    // Deserialize message field [speech]
    data.speech = Speech.deserialize(buffer, bufferOffset);
    // Deserialize message field [legs]
    data.legs = Legs.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.Needs.length;
    length += Gaze.getMessageSize(object.gaze);
    length += Emotion.getMessageSize(object.emotion);
    length += Arms.getMessageSize(object.arms);
    length += Speech.getMessageSize(object.speech);
    length += Legs.getMessageSize(object.legs);
    return length + 25;
  }

  static datatype() {
    // Returns string type for a message object
    return 'manage_pkg/bhvPara';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5fe673d03cab7a044fb7034673b9e171';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 num
    int64 time
    string Needs
    int8 CurOrder
    int8 TotalOrder
    float64 weight
    int8 TotalTime
    manage_pkg/Gaze gaze
    manage_pkg/Emotion emotion
    manage_pkg/Arms arms
    manage_pkg/Speech speech
    manage_pkg/Legs legs
    ================================================================================
    MSG: manage_pkg/Gaze
    bool call
    int8 weight
    string target
    int8 startTime
    int8 endTime
    ================================================================================
    MSG: manage_pkg/Emotion
    bool call
    int8 weight
    string type
    int8 startTime
    int8 endTime
    ================================================================================
    MSG: manage_pkg/Arms
    bool call
    int8 weight
    string action
    int8 rate
    int8 startTime
    int8 endTime
    ================================================================================
    MSG: manage_pkg/Speech
    bool call
    int8 weight
    string content
    int8 tone
    int8 rate
    int8 startTime
    int8 endTime
    ================================================================================
    MSG: manage_pkg/Legs
    bool call
    int8 weight
    string target
    string action
    int8 rate
    int8 distance
    int8 startTime
    int8 endTime
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new bhvPara(null);
    if (msg.num !== undefined) {
      resolved.num = msg.num;
    }
    else {
      resolved.num = 0
    }

    if (msg.time !== undefined) {
      resolved.time = msg.time;
    }
    else {
      resolved.time = 0
    }

    if (msg.Needs !== undefined) {
      resolved.Needs = msg.Needs;
    }
    else {
      resolved.Needs = ''
    }

    if (msg.CurOrder !== undefined) {
      resolved.CurOrder = msg.CurOrder;
    }
    else {
      resolved.CurOrder = 0
    }

    if (msg.TotalOrder !== undefined) {
      resolved.TotalOrder = msg.TotalOrder;
    }
    else {
      resolved.TotalOrder = 0
    }

    if (msg.weight !== undefined) {
      resolved.weight = msg.weight;
    }
    else {
      resolved.weight = 0.0
    }

    if (msg.TotalTime !== undefined) {
      resolved.TotalTime = msg.TotalTime;
    }
    else {
      resolved.TotalTime = 0
    }

    if (msg.gaze !== undefined) {
      resolved.gaze = Gaze.Resolve(msg.gaze)
    }
    else {
      resolved.gaze = new Gaze()
    }

    if (msg.emotion !== undefined) {
      resolved.emotion = Emotion.Resolve(msg.emotion)
    }
    else {
      resolved.emotion = new Emotion()
    }

    if (msg.arms !== undefined) {
      resolved.arms = Arms.Resolve(msg.arms)
    }
    else {
      resolved.arms = new Arms()
    }

    if (msg.speech !== undefined) {
      resolved.speech = Speech.Resolve(msg.speech)
    }
    else {
      resolved.speech = new Speech()
    }

    if (msg.legs !== undefined) {
      resolved.legs = Legs.Resolve(msg.legs)
    }
    else {
      resolved.legs = new Legs()
    }

    return resolved;
    }
};

module.exports = bhvPara;
