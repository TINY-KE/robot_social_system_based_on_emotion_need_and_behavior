// Auto-generated. Do not edit!

// (in-package manage_pkg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class bhvGet {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Needs = null;
      this.object = null;
      this.SelfMood = null;
      this.ObjMood = null;
      this.Speech = null;
    }
    else {
      if (initObj.hasOwnProperty('Needs')) {
        this.Needs = initObj.Needs
      }
      else {
        this.Needs = '';
      }
      if (initObj.hasOwnProperty('object')) {
        this.object = initObj.object
      }
      else {
        this.object = '';
      }
      if (initObj.hasOwnProperty('SelfMood')) {
        this.SelfMood = initObj.SelfMood
      }
      else {
        this.SelfMood = '';
      }
      if (initObj.hasOwnProperty('ObjMood')) {
        this.ObjMood = initObj.ObjMood
      }
      else {
        this.ObjMood = '';
      }
      if (initObj.hasOwnProperty('Speech')) {
        this.Speech = initObj.Speech
      }
      else {
        this.Speech = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type bhvGet
    // Serialize message field [Needs]
    bufferOffset = _serializer.string(obj.Needs, buffer, bufferOffset);
    // Serialize message field [object]
    bufferOffset = _serializer.string(obj.object, buffer, bufferOffset);
    // Serialize message field [SelfMood]
    bufferOffset = _serializer.string(obj.SelfMood, buffer, bufferOffset);
    // Serialize message field [ObjMood]
    bufferOffset = _serializer.string(obj.ObjMood, buffer, bufferOffset);
    // Serialize message field [Speech]
    bufferOffset = _serializer.string(obj.Speech, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type bhvGet
    let len;
    let data = new bhvGet(null);
    // Deserialize message field [Needs]
    data.Needs = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [object]
    data.object = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [SelfMood]
    data.SelfMood = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [ObjMood]
    data.ObjMood = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [Speech]
    data.Speech = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.Needs.length;
    length += object.object.length;
    length += object.SelfMood.length;
    length += object.ObjMood.length;
    length += object.Speech.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'manage_pkg/bhvGet';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '356c7ee4047989345e3f292967a5052e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string Needs
    string object
    string SelfMood
    string ObjMood
    string Speech
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new bhvGet(null);
    if (msg.Needs !== undefined) {
      resolved.Needs = msg.Needs;
    }
    else {
      resolved.Needs = ''
    }

    if (msg.object !== undefined) {
      resolved.object = msg.object;
    }
    else {
      resolved.object = ''
    }

    if (msg.SelfMood !== undefined) {
      resolved.SelfMood = msg.SelfMood;
    }
    else {
      resolved.SelfMood = ''
    }

    if (msg.ObjMood !== undefined) {
      resolved.ObjMood = msg.ObjMood;
    }
    else {
      resolved.ObjMood = ''
    }

    if (msg.Speech !== undefined) {
      resolved.Speech = msg.Speech;
    }
    else {
      resolved.Speech = ''
    }

    return resolved;
    }
};

module.exports = bhvGet;
