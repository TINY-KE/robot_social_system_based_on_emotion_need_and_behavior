#!/usr/bin/env sh
# generated from catkin.builder Python module

/home/kod/manage16_ws/devel_isolated/manage_pkg/env.sh "$@"
