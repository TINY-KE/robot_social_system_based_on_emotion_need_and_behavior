#!/usr/bin/env bash
# generated from catkin.builder Python module

. "/home/kod/manage16_ws/devel_isolated/manage_pkg/setup.bash"
