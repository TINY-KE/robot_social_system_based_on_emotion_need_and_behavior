
"use strict";

let perception_msg = require('./perception_msg.js');
let robot_emotion = require('./robot_emotion.js');
let need_satisfy_msg = require('./need_satisfy_msg.js');
let attitude_msg = require('./attitude_msg.js');

module.exports = {
  perception_msg: perception_msg,
  robot_emotion: robot_emotion,
  need_satisfy_msg: need_satisfy_msg,
  attitude_msg: attitude_msg,
};
