// Auto-generated. Do not edit!

// (in-package robot_empathy.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class need_satisfy_msg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.need_name = null;
      this.satisfy_value = null;
    }
    else {
      if (initObj.hasOwnProperty('need_name')) {
        this.need_name = initObj.need_name
      }
      else {
        this.need_name = '';
      }
      if (initObj.hasOwnProperty('satisfy_value')) {
        this.satisfy_value = initObj.satisfy_value
      }
      else {
        this.satisfy_value = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type need_satisfy_msg
    // Serialize message field [need_name]
    bufferOffset = _serializer.string(obj.need_name, buffer, bufferOffset);
    // Serialize message field [satisfy_value]
    bufferOffset = _serializer.int8(obj.satisfy_value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type need_satisfy_msg
    let len;
    let data = new need_satisfy_msg(null);
    // Deserialize message field [need_name]
    data.need_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [satisfy_value]
    data.satisfy_value = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.need_name.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robot_empathy/need_satisfy_msg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '634ef29362aff3842b566644772a123d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string need_name    		# 需求的名称
    int8 satisfy_value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new need_satisfy_msg(null);
    if (msg.need_name !== undefined) {
      resolved.need_name = msg.need_name;
    }
    else {
      resolved.need_name = ''
    }

    if (msg.satisfy_value !== undefined) {
      resolved.satisfy_value = msg.satisfy_value;
    }
    else {
      resolved.satisfy_value = 0
    }

    return resolved;
    }
};

module.exports = need_satisfy_msg;
