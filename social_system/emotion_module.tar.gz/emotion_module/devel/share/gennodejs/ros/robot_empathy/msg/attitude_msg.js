// Auto-generated. Do not edit!

// (in-package robot_empathy.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class attitude_msg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.person_name = null;
      this.attitude = null;
    }
    else {
      if (initObj.hasOwnProperty('person_name')) {
        this.person_name = initObj.person_name
      }
      else {
        this.person_name = '';
      }
      if (initObj.hasOwnProperty('attitude')) {
        this.attitude = initObj.attitude
      }
      else {
        this.attitude = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type attitude_msg
    // Serialize message field [person_name]
    bufferOffset = _serializer.string(obj.person_name, buffer, bufferOffset);
    // Serialize message field [attitude]
    bufferOffset = _serializer.string(obj.attitude, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type attitude_msg
    let len;
    let data = new attitude_msg(null);
    // Deserialize message field [person_name]
    data.person_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [attitude]
    data.attitude = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.person_name.length;
    length += object.attitude.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robot_empathy/attitude_msg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a9b22f731826ed625dc0cabe20294d2e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string person_name 	 # 交互对象（用户）的姓名
    string attitude			# 机器人对该交互对象的社交态度
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new attitude_msg(null);
    if (msg.person_name !== undefined) {
      resolved.person_name = msg.person_name;
    }
    else {
      resolved.person_name = ''
    }

    if (msg.attitude !== undefined) {
      resolved.attitude = msg.attitude;
    }
    else {
      resolved.attitude = ''
    }

    return resolved;
    }
};

module.exports = attitude_msg;
